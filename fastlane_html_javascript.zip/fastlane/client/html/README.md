# HTML

This is a basic HTML/JS implementation of a checkout page integrated with Fastlane.

## Local testing

1. Make sure that your server of choice is running locally. For more information, see the README at the root of this repository.

2. Go to [localhost:8080](localhost:8080) for the Quick Start Integration or [localhost:8080/?flexible](localhost:8080/?flexible) for the Flexible Integration.